
public class C1_Q1 {
	public static void main(String[] args) {
		int a = 0;
		int b, sum;
		a = a+1;
		b = 7;
		sum = a+b;
		System.out.println("a + b = " + sum);
	}
}
